google-services.json은 Project 목록에서 app폴더에 넣으면 된다.

google-services.json은 파이어베이스를 쓸 수 있도록 연동해주는 api 라고 생각하면 좋다.

=================

gradle에 project랑 app 따로 나뉘어져 있는데

겹치는 코드가 일어나지 않도록 제어하길 바람.

=================

