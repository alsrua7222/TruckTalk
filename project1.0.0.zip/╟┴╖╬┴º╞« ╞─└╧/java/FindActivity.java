package com.kmk99.nwpteam1project;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class FindActivity extends AppCompatActivity {
    private EditText et_phone, et_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.find);

        et_phone = findViewById(R.id.find_phone);
        et_id = findViewById(R.id.find_id);
    }
    private void resultFinish(int resultCode, Intent data){
        setResult(resultCode, data);
        finish();
    }
    public void onClick(View v){
        String phone = et_phone.getText().toString();
        String id = et_id.getText().toString();
        boolean b_result = false;
        switch(v.getId()){
            case R.id.find_find_id:
                /**
                 * Phone 입력 필수
                 */
                if(phone.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("휴대폰 번호 입력하세요.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else{
                    /**
                     * Phone 질의하기
                     */
                    if(b_result){
                        /**
                         * 찾기 성공 액티비티로 넘어간다.
                         * resultfinish()를 사용한다.
                         */

                    }
                    else{
                        /**
                         * 일치 실패했을 때 변화 없음.
                         */
                    }
                }
                break;
            case R.id.find_find_pw:
                /**
                 * Phone, ID 입력 필수
                 */
                if(phone.isEmpty()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("휴대폰 번호 입력하세요.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if(id.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("아이디 입력하세요.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else{
                    Account.getInstance().setPhone(phone);
                    Account.getInstance().setID(id);

                    /**
                     * Phone, ID 질의하기
                    * */

                    if(b_result){
                        /**
                         * 찾기 성공 액티비티로 넘어간다.
                         * resultfinish()를 사용한다.
                         */
                    }
                    else{
                        /**
                         * 일치 실패했을 때 변화 없음.
                         */
                    }
                }
                break;
        }
    }
}
