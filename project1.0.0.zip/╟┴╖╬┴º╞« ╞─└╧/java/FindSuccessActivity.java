package com.kmk99.nwpteam1project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class FindSuccessActivity extends AppCompatActivity {
    private EditText et_pw, et_pw2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.find);

        et_pw = findViewById(R.id.find_s_pw);
        et_pw2 = findViewById(R.id.find_s_pw2);
    }
    private void resultFinish(int resultCode, Intent data){
        setResult(resultCode, data);
        finish();
    }
    public void onClick(View v){
        switch (v.getId()){
            case R.id.find_s_rec:
                String pw = et_pw.getText().toString();
                String pw2 = et_pw2.getText().toString();
                if(pw.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("새로운 비밀번호 입력하세요.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if(pw2.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("새로운 2차 비밀번호 입력하세요.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if(pw.equals(pw2)){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("새로운 비밀번호 생성되었습니다.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    /**
                     * 해당 아이디의 비밀번호 업데이트
                     * 여기 액티비티를 종료 뒤에 로그인 화면으로 돌아간다.
                     */
                }
                else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("새로운 비밀번호가 일치해야 합니다.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                break;
        }
    }
}
