package com.kmk99.nwpteam1project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    private EditText et_id, et_pw;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference profile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent(this, SettingActivity.class);
        startActivity(intent);

        firebaseDatabase = FirebaseDatabase.getInstance();
        profile = firebaseDatabase.getReference("user");

        et_id = findViewById(R.id.login_id);
        et_pw = findViewById(R.id.login_pw);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            if(resultCode == RESULT_OK){
                /**
                 * 여기에 찾기 액티비티 기능
                 */
            }
        }
    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.login_login:
                String id = et_id.getText().toString();
                String pw = et_pw.getText().toString();
                if(id.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("아이디 입력하세요.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if(pw.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("비밀번호 입력하세요.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else{
                    Account.getInstance().setID(id);
                    Account.getInstance().setPW(pw);

                    /**
                    * DatabaseReference를 통해서 질의하기.
                    * */
                }
                break;
            case R.id.login_find:
                /**
                 * 찾기 액티비티
                 */
                Intent intent_f = new Intent(this, FindActivity.class);
                startActivityForResult(intent_f, 1);
                break;
            case R.id.login_sign:
                /**
                 * 회원가입 액티비티
                 */
                Intent intent_s = new Intent(this, SignupActivity.class);
                startActivityForResult(intent_s, 2);
                break;
        }
    }
}
