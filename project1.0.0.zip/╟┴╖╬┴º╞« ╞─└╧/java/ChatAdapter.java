package com.kmk99.nwpteam1project;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatAdapter extends BaseAdapter {
    ArrayList<MessageItem> m_messageItems;
    LayoutInflater m_layoutInflater;

    public ChatAdapter(ArrayList<MessageItem> messageItems, LayoutInflater layoutInflater){
        this.m_messageItems = messageItems;
        this.m_layoutInflater = layoutInflater;
    }
    @Override
    public int getCount() {
        return m_messageItems.size();
    }

    @Override
    public Object getItem(int position) {
        return m_messageItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MessageItem item = m_messageItems.get(position);
        View itemView = null;
        CircleImageView iv;
        TextView tv_name, tv_msg, tv_time;
        if(item.getName().equals(Account.getInstance().getName())){ //내 채팅
            itemView = m_layoutInflater.inflate(R.layout.chat_my_msg, parent, false);
            tv_msg = itemView.findViewById(R.id.chat_my_msg);
            tv_time = itemView.findViewById(R.id.chat_my_time);

            tv_msg.setText(item.getMsg());
            tv_time.setText(item.getTime());
        }
        else{//다른 채팅
            itemView = m_layoutInflater.inflate(R.layout.chat_other_msg, parent, false);

            iv = itemView.findViewById(R.id.chat_other_prof);
            tv_name = itemView.findViewById(R.id.chat_other_name);
            tv_msg = itemView.findViewById(R.id.chat_other_msg);
            tv_time = itemView.findViewById(R.id.chat_other_time);

            Picasso.get().load(item.getProfurl()).into(iv);
            tv_name.setText(item.getName());
            tv_msg.setText(item.getMsg());
            tv_time.setText(item.getTime());
        }

        return itemView;

    }
}
