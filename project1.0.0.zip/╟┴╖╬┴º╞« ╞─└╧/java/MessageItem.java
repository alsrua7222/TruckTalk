package com.kmk99.nwpteam1project;

public class MessageItem {
    private String m_an, m_name, m_msg, m_time, m_profurl;

    public MessageItem(String name, String msg, String time, String profurl){
        this.m_name = name;
        this.m_msg = msg;
        this.m_time = time;
        this.m_profurl = profurl;
    }
    public MessageItem(String an, String name, String msg, String time, String profurl){
        this.m_an = an;
        this.m_name = name;
        this.m_msg = msg;
        this.m_time = time;
        this.m_profurl = profurl;
    }
    public MessageItem(){
        /**
         * 작성할 필요가 없음. 파이어베이스 객체를 이용하려면 어레이 리스트에 생성자 필요함.
         */
    }

    public String getAN() {
        return m_an;
    }

    public void setAN(String m_an) {
        this.m_an = m_an;
    }

    public String getName() {
        return m_name;
    }

    public void setName(String m_name) {
        this.m_name = m_name;
    }

    public String getMsg() {
        return m_msg;
    }

    public void setMsg(String m_msg) {
        this.m_msg = m_msg;
    }

    public String getTime() {
        return m_time;
    }

    public void setTime(String m_time) {
        this.m_time = m_time;
    }

    public String getProfurl() {
        return m_profurl;
    }

    public void setProfurl(String m_profurl) {
        this.m_profurl = m_profurl;
    }

}
