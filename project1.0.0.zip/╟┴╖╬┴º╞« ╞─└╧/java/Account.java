package com.kmk99.nwpteam1project;

import android.content.Context;

public class Account {
    private static Account s_instance;
    private Context m_context;

    private String m_id;
    private String m_pw;
    private String m_name;
    private String m_phone;
    private String m_url;

    public static Account getInstance(){
        if(s_instance == null){
            s_instance = new Account();
        }
        return s_instance;
    }
    public void setID(String id){
        m_id = id;
    }
    public String getID(){
        return m_id;
    }
    public void setPW(String pw){
        m_pw = pw;
    }
    public String getPW(){
        return m_pw;
    }
    public void setName(String name) { m_name = name; }
    public String getName(){ return m_name; }
    public void setPhone(String phone){
        m_phone = phone;
    }
    public String getPhone(){
        return m_phone;
    }
    public void setProfUrl(String url){ m_url = url; }
    public String getProfUrl(){ return m_url; }
    public void setContext(Context context){
        m_context = context;
    }
    public Context getContext(){
        return m_context;
    }
}
