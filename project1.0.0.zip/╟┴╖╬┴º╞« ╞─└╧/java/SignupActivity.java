package com.kmk99.nwpteam1project;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class SignupActivity extends AppCompatActivity {
    private CircleImageView iv_prof;
    private EditText et_phone, et_id, et_pw, et_name;

    Uri imgUri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.find);

        et_phone = findViewById(R.id.su_phone);
        et_id = findViewById(R.id.su_id);
        et_pw = findViewById(R.id.su_pw);
        et_name = findViewById(R.id.su_name);
        iv_prof = findViewById(R.id.su_prof);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 10:
                if(resultCode == RESULT_OK){
                    imgUri = data.getData();
                    Picasso.get().load(imgUri).into(iv_prof);
                }
                break;
        }
    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.su_prof:
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, 10);
                break;
            case R.id.su_bt:
                String phone, id, pw, name;
                phone = et_phone.getText().toString();
                id = et_id.getText().toString();
                pw = et_pw.getText().toString();
                name = et_name.getText().toString();

                if(phone.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("폰 번호 입력하세요.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if(id.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("아이디 입력하세요.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if(pw.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("비밀번호 입력하세요.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else if(name.isEmpty()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Error").setMessage("이름 입력하세요.");
                    builder.setPositiveButton("확인", null);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                else{
                    /**
                     * if문에 파이어베이스에 있는 Phone이나 id 일치 여부 넣기.
                     * 일치하면 쓸 수 없다고 하기.
                     * 일치하지 않으면 회원가입 된다고 하기.
                     */
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Question").setMessage("회원 가입 하겠습니까?");
                    builder.setPositiveButton("예", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialog, int which){
                            /**
                             * 회원가입 하면 파이어 베이스 저장한 뒤 로그인 화면으로 돌아감.
                             */
                        }
                    });
                    builder.setNegativeButton("아니요", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            /**
                             * 회원가입 안하면 아무 서비스를 실행하지 않음.
                             */
                        }
                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                break;
        }
    }
}
